var menu = document.getElementById('nav-menu-bar');

function myFunction(x){
    x.classList.toggle("change");
    menu.classList.toggle("menu-active")
}